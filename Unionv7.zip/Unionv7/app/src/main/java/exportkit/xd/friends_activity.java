
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		home
	 *	@date 		1612057565888
	 *	@title 		Home
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.xd
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.content.Intent;
import android.widget.TextView;

public class friends_activity extends Activity {

	
	private View _bg__friends_ek3;
	private View rectangle_1_ek5;
	private ImageView _icon_awesome_search_location_ek5;
	private ImageView _icon_ionic_ios_settings_ek5;
	private ImageView _icon_awesome_file_alt_ek5;
	private ImageView _icon_awesome_hands_helping_ek5;
	private TextView friends_ek4;
	private View rectangle_23_ek6;
	private TextView add_friends;
	private ImageView path_5;
	private TextView emergency_contact;
	private View rectangle_23_ek7;
	private TextView phone_calls_ek1;
	private ImageView path_3;
	private ImageView path_4;
	private ImageView path_3_ek1;
	private ImageView path_4_ek1;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.friends);

		
		_bg__friends_ek3 = (View) findViewById(R.id._bg__friends_ek3);
		rectangle_1_ek5 = (View) findViewById(R.id.rectangle_1_ek5);
		_icon_awesome_search_location_ek5 = (ImageView) findViewById(R.id._icon_awesome_search_location_ek5);
		_icon_ionic_ios_settings_ek5 = (ImageView) findViewById(R.id._icon_ionic_ios_settings_ek5);
		_icon_awesome_file_alt_ek5 = (ImageView) findViewById(R.id._icon_awesome_file_alt_ek5);
		_icon_awesome_hands_helping_ek5 = (ImageView) findViewById(R.id._icon_awesome_hands_helping_ek5);
		friends_ek4 = (TextView) findViewById(R.id.friends_ek4);
		rectangle_23_ek6 = (View) findViewById(R.id.rectangle_23_ek6);
		add_friends = (TextView) findViewById(R.id.add_friends);
		path_5 = (ImageView) findViewById(R.id.path_5);
		emergency_contact = (TextView) findViewById(R.id.emergency_contact);
		rectangle_23_ek7 = (View) findViewById(R.id.rectangle_23_ek7);
		phone_calls_ek1 = (TextView) findViewById(R.id.phone_calls_ek1);
		path_3 = (ImageView) findViewById(R.id.path_3);
		path_4 = (ImageView) findViewById(R.id.path_4);
		path_3_ek1 = (ImageView) findViewById(R.id.path_3_ek1);
		path_4_ek1 = (ImageView) findViewById(R.id.path_4_ek1);
	
		
		_icon_awesome_search_location_ek5.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), home_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		_icon_ionic_ios_settings_ek5.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), settings_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		_icon_awesome_file_alt_ek5.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), forms_and_shit_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		_icon_awesome_hands_helping_ek5.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), support_and_such_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		//custom code goes here
	
	}
}
	
	