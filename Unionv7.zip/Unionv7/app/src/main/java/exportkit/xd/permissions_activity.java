
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		home
	 *	@date 		1612057565888
	 *	@title 		Home
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.xd
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.content.Intent;
import android.widget.TextView;

public class permissions_activity extends Activity {

	
	private View _bg__permissions_ek3;
	private View rectangle_1_ek4;
	private ImageView _icon_awesome_search_location_ek4;
	private ImageView _icon_ionic_ios_settings_ek4;
	private ImageView _icon_awesome_file_alt_ek4;
	private ImageView _icon_awesome_hands_helping_ek4;
	private TextView permissions_ek4;
	private View rectangle_23_ek3;
	private TextView microphone;
	private View rectangle_23_ek4;
	private TextView location;
	private View rectangle_23_ek5;
	private TextView phone_calls;
	private View rectangle_60;
	private View ellipse_12;
	private View rectangle_60_ek1;
	private View ellipse_12_ek1;
	private View rectangle_60_ek2;
	private View ellipse_12_ek2;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.permissions);

		
		_bg__permissions_ek3 = (View) findViewById(R.id._bg__permissions_ek3);
		rectangle_1_ek4 = (View) findViewById(R.id.rectangle_1_ek4);
		_icon_awesome_search_location_ek4 = (ImageView) findViewById(R.id._icon_awesome_search_location_ek4);
		_icon_ionic_ios_settings_ek4 = (ImageView) findViewById(R.id._icon_ionic_ios_settings_ek4);
		_icon_awesome_file_alt_ek4 = (ImageView) findViewById(R.id._icon_awesome_file_alt_ek4);
		_icon_awesome_hands_helping_ek4 = (ImageView) findViewById(R.id._icon_awesome_hands_helping_ek4);
		permissions_ek4 = (TextView) findViewById(R.id.permissions_ek4);
		rectangle_23_ek3 = (View) findViewById(R.id.rectangle_23_ek3);
		microphone = (TextView) findViewById(R.id.microphone);
		rectangle_23_ek4 = (View) findViewById(R.id.rectangle_23_ek4);
		location = (TextView) findViewById(R.id.location);
		rectangle_23_ek5 = (View) findViewById(R.id.rectangle_23_ek5);
		phone_calls = (TextView) findViewById(R.id.phone_calls);
		rectangle_60 = (View) findViewById(R.id.rectangle_60);
		ellipse_12 = (View) findViewById(R.id.ellipse_12);
		rectangle_60_ek1 = (View) findViewById(R.id.rectangle_60_ek1);
		ellipse_12_ek1 = (View) findViewById(R.id.ellipse_12_ek1);
		rectangle_60_ek2 = (View) findViewById(R.id.rectangle_60_ek2);
		ellipse_12_ek2 = (View) findViewById(R.id.ellipse_12_ek2);
	
		
		_icon_awesome_search_location_ek4.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), home_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		_icon_ionic_ios_settings_ek4.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), settings_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		_icon_awesome_file_alt_ek4.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), forms_and_shit_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		_icon_awesome_hands_helping_ek4.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), support_and_such_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		//custom code goes here
	
	}
}
	
	