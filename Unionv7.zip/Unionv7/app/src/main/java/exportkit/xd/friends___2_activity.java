
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		home
	 *	@date 		1612057565888
	 *	@title 		Home
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.xd
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.content.Intent;
import android.widget.TextView;

public class friends___2_activity extends Activity {

	
	private View _bg__friends___2_ek2;
	private View rectangle_1_ek6;
	private ImageView _icon_awesome_search_location_ek6;
	private ImageView _icon_ionic_ios_settings_ek6;
	private ImageView _icon_awesome_file_alt_ek6;
	private ImageView _icon_awesome_hands_helping_ek6;
	private View rectangle_23_ek8;
	private TextView connect;
	private ImageView path_3_ek2;
	private ImageView path_4_ek2;
	private TextView connect_union_home_ek1;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.friends___2);

		
		_bg__friends___2_ek2 = (View) findViewById(R.id._bg__friends___2_ek2);
		rectangle_1_ek6 = (View) findViewById(R.id.rectangle_1_ek6);
		_icon_awesome_search_location_ek6 = (ImageView) findViewById(R.id._icon_awesome_search_location_ek6);
		_icon_ionic_ios_settings_ek6 = (ImageView) findViewById(R.id._icon_ionic_ios_settings_ek6);
		_icon_awesome_file_alt_ek6 = (ImageView) findViewById(R.id._icon_awesome_file_alt_ek6);
		_icon_awesome_hands_helping_ek6 = (ImageView) findViewById(R.id._icon_awesome_hands_helping_ek6);
		rectangle_23_ek8 = (View) findViewById(R.id.rectangle_23_ek8);
		connect = (TextView) findViewById(R.id.connect);
		path_3_ek2 = (ImageView) findViewById(R.id.path_3_ek2);
		path_4_ek2 = (ImageView) findViewById(R.id.path_4_ek2);
		connect_union_home_ek1 = (TextView) findViewById(R.id.connect_union_home_ek1);
	
		
		_icon_awesome_search_location_ek6.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), home_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		_icon_ionic_ios_settings_ek6.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), settings_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		_icon_awesome_file_alt_ek6.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), forms_and_shit_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		_icon_awesome_hands_helping_ek6.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), support_and_such_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		//custom code goes here
	
	}
}
	
	