
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		home
	 *	@date 		1612057565888
	 *	@title 		Home
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.xd
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.content.Intent;
import android.widget.TextView;

public class support_and_such_activity extends Activity {

	
	private View _bg__support_and_such_ek2;
	private View rectangle_1_ek2;
	private ImageView _icon_awesome_search_location_ek2;
	private ImageView _icon_ionic_ios_settings_ek2;
	private ImageView _icon_awesome_file_alt_ek2;
	private ImageView icon_awesome_hands_helping_ek2;
	private View rectangle_20;
	private TextView steps_after_sexual_assult;
	private View rectangle_21;
	private TextView help_lines;
	private View rectangle_22;
	private TextView support_groups;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.support_and_such);

		
		_bg__support_and_such_ek2 = (View) findViewById(R.id._bg__support_and_such_ek2);
		rectangle_1_ek2 = (View) findViewById(R.id.rectangle_1_ek2);
		_icon_awesome_search_location_ek2 = (ImageView) findViewById(R.id._icon_awesome_search_location_ek2);
		_icon_ionic_ios_settings_ek2 = (ImageView) findViewById(R.id._icon_ionic_ios_settings_ek2);
		_icon_awesome_file_alt_ek2 = (ImageView) findViewById(R.id._icon_awesome_file_alt_ek2);
		icon_awesome_hands_helping_ek2 = (ImageView) findViewById(R.id.icon_awesome_hands_helping_ek2);
		rectangle_20 = (View) findViewById(R.id.rectangle_20);
		steps_after_sexual_assult = (TextView) findViewById(R.id.steps_after_sexual_assult);
		rectangle_21 = (View) findViewById(R.id.rectangle_21);
		help_lines = (TextView) findViewById(R.id.help_lines);
		rectangle_22 = (View) findViewById(R.id.rectangle_22);
		support_groups = (TextView) findViewById(R.id.support_groups);
	
		
		_icon_awesome_search_location_ek2.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), home_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		_icon_ionic_ios_settings_ek2.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), settings_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		_icon_awesome_file_alt_ek2.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), forms_and_shit_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		//custom code goes here
	
	}
}
	
	