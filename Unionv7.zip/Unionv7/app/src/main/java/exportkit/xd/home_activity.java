
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		home
	 *	@date 		1612057565888
	 *	@title 		Home
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.xd
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;

public class home_activity extends Activity {

	
	private View _bg__home_ek2;
	private View rectangle_9;
	private ImageView ellipse_3;
	private View rectangle_9_ek1;
	private ImageView ellipse_3_ek1;
	private TextView olivia_styles;
	private TextView hannah_rellar;
	private TextView home_ek3;
	private TextView detroit_kroger;
	private View rectangle_9_ek2;
	private View rectangle_10;
	private ImageView ellipse_3_ek2;
	private ImageView ellipse_4;
	private TextView kaitlynn_ray;
	private TextView shelby_thompson;
	private TextView detroit_home_depot;
	private TextView home_ek4;
	private View rectangle_8;
	private View rectangle_5;
	private View rectangle_7;
	private View rectangle_1;
	private ImageView icon_awesome_search_location;
	private ImageView _icon_ionic_ios_settings;
	private ImageView _icon_awesome_file_alt;
	private ImageView _icon_awesome_hands_helping;
	private ImageView mask_group_1;
	private ImageView icon_material_location_on;
	private ImageView ellipse_6;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.home);

		
		_bg__home_ek2 = (View) findViewById(R.id._bg__home_ek2);
		rectangle_9 = (View) findViewById(R.id.rectangle_9);
		ellipse_3 = (ImageView) findViewById(R.id.ellipse_3);
		rectangle_9_ek1 = (View) findViewById(R.id.rectangle_9_ek1);
		ellipse_3_ek1 = (ImageView) findViewById(R.id.ellipse_3_ek1);
		olivia_styles = (TextView) findViewById(R.id.olivia_styles);
		hannah_rellar = (TextView) findViewById(R.id.hannah_rellar);
		home_ek3 = (TextView) findViewById(R.id.home_ek3);
		detroit_kroger = (TextView) findViewById(R.id.detroit_kroger);
		rectangle_9_ek2 = (View) findViewById(R.id.rectangle_9_ek2);
		rectangle_10 = (View) findViewById(R.id.rectangle_10);
		ellipse_3_ek2 = (ImageView) findViewById(R.id.ellipse_3_ek2);
		ellipse_4 = (ImageView) findViewById(R.id.ellipse_4);
		kaitlynn_ray = (TextView) findViewById(R.id.kaitlynn_ray);
		shelby_thompson = (TextView) findViewById(R.id.shelby_thompson);
		detroit_home_depot = (TextView) findViewById(R.id.detroit_home_depot);
		home_ek4 = (TextView) findViewById(R.id.home_ek4);
		rectangle_8 = (View) findViewById(R.id.rectangle_8);
		rectangle_5 = (View) findViewById(R.id.rectangle_5);
		rectangle_7 = (View) findViewById(R.id.rectangle_7);
		rectangle_1 = (View) findViewById(R.id.rectangle_1);
		icon_awesome_search_location = (ImageView) findViewById(R.id.icon_awesome_search_location);
		_icon_ionic_ios_settings = (ImageView) findViewById(R.id._icon_ionic_ios_settings);
		_icon_awesome_file_alt = (ImageView) findViewById(R.id._icon_awesome_file_alt);
		_icon_awesome_hands_helping = (ImageView) findViewById(R.id._icon_awesome_hands_helping);
		mask_group_1 = (ImageView) findViewById(R.id.mask_group_1);
		icon_material_location_on = (ImageView) findViewById(R.id.icon_material_location_on);
		ellipse_6 = (ImageView) findViewById(R.id.ellipse_6);
	
		
		_icon_ionic_ios_settings.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), settings_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		_icon_awesome_file_alt.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), forms_and_shit_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		_icon_awesome_hands_helping.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), support_and_such_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		//custom code goes here
	
	}
}
	
	