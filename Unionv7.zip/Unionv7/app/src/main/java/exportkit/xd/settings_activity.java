
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		home
	 *	@date 		1612057565888
	 *	@title 		Home
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.xd
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.content.Intent;
import android.widget.ImageView;
import android.widget.TextView;

public class settings_activity extends Activity {

	
	private View __bg__settings_ek2;
	private View rectangle_1_ek3;
	private ImageView _icon_awesome_search_location_ek3;
	private ImageView icon_ionic_ios_settings_ek3;
	private ImageView _icon_awesome_file_alt_ek3;
	private ImageView _icon_awesome_hands_helping_ek3;
	private TextView settings_ek3;
	private View rectangle_23;
	private ImageView icon_awesome_shield_alt;
	private TextView permissions;
	private View _rectangle_23_ek1;
	private TextView set_voice_recognition;
	private View _rectangle_23_ek2;
	private TextView friends;
	private View _rectangle_61;
	private TextView connect_union_home;
	private ImageView icon_awesome_microphone;
	private ImageView icon_awesome_user_friends;
	private ImageView icon_material_computer;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.settings);

		
		__bg__settings_ek2 = (View) findViewById(R.id.__bg__settings_ek2);
		rectangle_1_ek3 = (View) findViewById(R.id.rectangle_1_ek3);
		_icon_awesome_search_location_ek3 = (ImageView) findViewById(R.id._icon_awesome_search_location_ek3);
		icon_ionic_ios_settings_ek3 = (ImageView) findViewById(R.id.icon_ionic_ios_settings_ek3);
		_icon_awesome_file_alt_ek3 = (ImageView) findViewById(R.id._icon_awesome_file_alt_ek3);
		_icon_awesome_hands_helping_ek3 = (ImageView) findViewById(R.id._icon_awesome_hands_helping_ek3);
		settings_ek3 = (TextView) findViewById(R.id.settings_ek3);
		rectangle_23 = (View) findViewById(R.id.rectangle_23);
		icon_awesome_shield_alt = (ImageView) findViewById(R.id.icon_awesome_shield_alt);
		permissions = (TextView) findViewById(R.id.permissions);
		_rectangle_23_ek1 = (View) findViewById(R.id._rectangle_23_ek1);
		set_voice_recognition = (TextView) findViewById(R.id.set_voice_recognition);
		_rectangle_23_ek2 = (View) findViewById(R.id._rectangle_23_ek2);
		friends = (TextView) findViewById(R.id.friends);
		_rectangle_61 = (View) findViewById(R.id._rectangle_61);
		connect_union_home = (TextView) findViewById(R.id.connect_union_home);
		icon_awesome_microphone = (ImageView) findViewById(R.id.icon_awesome_microphone);
		icon_awesome_user_friends = (ImageView) findViewById(R.id.icon_awesome_user_friends);
		icon_material_computer = (ImageView) findViewById(R.id.icon_material_computer);
	
		
		__bg__settings_ek2.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), permissions_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		_icon_awesome_search_location_ek3.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), home_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		_icon_awesome_file_alt_ek3.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), forms_and_shit_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		_icon_awesome_hands_helping_ek3.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), support_and_such_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		_rectangle_23_ek1.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), friends___1_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		_rectangle_23_ek2.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), friends_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		_rectangle_61.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), friends___2_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		//custom code goes here
	
	}
}
	
	