
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		home
	 *	@date 		1612057565888
	 *	@title 		Home
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.xd
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.content.Intent;
import android.widget.ImageView;
import android.widget.TextView;

public class home___1_activity extends Activity {

	
	private View _bg__home___1_ek2;
	private View ellipse_1;
	private View rectangle_2;
	private View _rectangle_4;
	private ImageView path_6;
	private TextView welcome_to_union;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.home___1);

		
		_bg__home___1_ek2 = (View) findViewById(R.id._bg__home___1_ek2);
		ellipse_1 = (View) findViewById(R.id.ellipse_1);
		rectangle_2 = (View) findViewById(R.id.rectangle_2);
		_rectangle_4 = (View) findViewById(R.id._rectangle_4);
		path_6 = (ImageView) findViewById(R.id.path_6);
		welcome_to_union = (TextView) findViewById(R.id.welcome_to_union);
	
		
		_rectangle_4.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), home_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		//custom code goes here
	
	}
}
	
	