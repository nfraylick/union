
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		home
	 *	@date 		1612057565888
	 *	@title 		Home
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.xd
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.content.Intent;
import android.widget.TextView;

public class forms_and_shit_activity extends Activity {

	
	private View _bg__forms_and_shit_ek2;
	private View rectangle_1_ek8;
	private ImageView _icon_awesome_search_location_ek8;
	private ImageView _icon_ionic_ios_settings_ek8;
	private ImageView icon_awesome_file_alt_ek8;
	private ImageView _icon_awesome_hands_helping_ek8;
	private TextView audio_recordings;
	private TextView consent_forms;
	private View rectangle_15;
	private View rectangle_17;
	private View rectangle_16;
	private View rectangle_18;
	private View rectangle_19;
	private TextView january_19__2021;
	private TextView december_23__2020;
	private TextView may_23__2020;
	private TextView december_1__2020;
	private TextView give_consent;
	private TextView detroit_48075;
	private TextView james_mccleery;
	private TextView detroit_48075_ek1;
	private TextView will_o_conner;
	private ImageView path_3_ek3;
	private ImageView path_4_ek3;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.forms_and_shit);

		
		_bg__forms_and_shit_ek2 = (View) findViewById(R.id._bg__forms_and_shit_ek2);
		rectangle_1_ek8 = (View) findViewById(R.id.rectangle_1_ek8);
		_icon_awesome_search_location_ek8 = (ImageView) findViewById(R.id._icon_awesome_search_location_ek8);
		_icon_ionic_ios_settings_ek8 = (ImageView) findViewById(R.id._icon_ionic_ios_settings_ek8);
		icon_awesome_file_alt_ek8 = (ImageView) findViewById(R.id.icon_awesome_file_alt_ek8);
		_icon_awesome_hands_helping_ek8 = (ImageView) findViewById(R.id._icon_awesome_hands_helping_ek8);
		audio_recordings = (TextView) findViewById(R.id.audio_recordings);
		consent_forms = (TextView) findViewById(R.id.consent_forms);
		rectangle_15 = (View) findViewById(R.id.rectangle_15);
		rectangle_17 = (View) findViewById(R.id.rectangle_17);
		rectangle_16 = (View) findViewById(R.id.rectangle_16);
		rectangle_18 = (View) findViewById(R.id.rectangle_18);
		rectangle_19 = (View) findViewById(R.id.rectangle_19);
		january_19__2021 = (TextView) findViewById(R.id.january_19__2021);
		december_23__2020 = (TextView) findViewById(R.id.december_23__2020);
		may_23__2020 = (TextView) findViewById(R.id.may_23__2020);
		december_1__2020 = (TextView) findViewById(R.id.december_1__2020);
		give_consent = (TextView) findViewById(R.id.give_consent);
		detroit_48075 = (TextView) findViewById(R.id.detroit_48075);
		james_mccleery = (TextView) findViewById(R.id.james_mccleery);
		detroit_48075_ek1 = (TextView) findViewById(R.id.detroit_48075_ek1);
		will_o_conner = (TextView) findViewById(R.id.will_o_conner);
		path_3_ek3 = (ImageView) findViewById(R.id.path_3_ek3);
		path_4_ek3 = (ImageView) findViewById(R.id.path_4_ek3);
	
		
		_icon_awesome_search_location_ek8.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), home_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		_icon_ionic_ios_settings_ek8.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), settings_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		_icon_awesome_hands_helping_ek8.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), support_and_such_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		//custom code goes here
	
	}
}
	
	